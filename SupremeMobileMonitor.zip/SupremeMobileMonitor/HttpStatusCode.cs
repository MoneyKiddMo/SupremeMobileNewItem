﻿namespace SupremeMobileMonitor
{
    internal class HttpStatusCode
    {
    }
}